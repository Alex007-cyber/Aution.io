<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aution</title>
    <link rel="stylesheet" href="estilos2.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100&display=swap" rel="stylesheet">

    <?php require 'header.php'?>
<h1>Bienvenidos</h1>
</head>
<body>

<a href="entrar.php">Entrar</a> or
<a href="registrar.php">registro</a>

</body>
</html>